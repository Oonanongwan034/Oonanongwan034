package com.devskiller.controller;

import java.util.List;

public class ItemController {

    public List<String> getTitles(Double rating) {
        throw new UnsupportedOperationException();
    }
}
